<?php

	require_once('conex.php');
	$database = new Database();
	$db = $database->conectar();

	if (isset($_POST['delete']) && isset($_POST['id_evento'])){
		$id_evento = $_POST['id_evento'];

		$sql = "DELETE FROM eventos WHERE id_evento = $id_evento";
		$sql2 = "DELETE FROM convites WHERE fk_id_evento = $id_evento";

		$query2 = $db->prepare( $sql2 );
		$query = $db->prepare( $sql );
		if ($query == false) {
			print_r($db->errorInfo());
			die ('Error al cargar los turnos');
		}

		$res2 = $query2->execute();
		$res = $query->execute();
		if ($res == false) {
			print_r($query->errorInfo());
			die ('Error al consultar los turnos');
		}

	}else if (isset($_POST['titulo']) && isset($_POST['descripcion']) && isset($_POST['inicio']) && isset($_POST['termino']) && isset($_POST['cor']) && isset($_POST['id_evento'])){

		$id_evento = $_POST['id_evento'];
		$titulo = $_POST['titulo'];
		$descripcion = $_POST['descripcion'];
		$inicio = $_POST['inicio'];
		$termino = $_POST['termino'];
		$cor = $_POST['cor'];

		$inicio= date('Y/m/d H:i', strtotime($inicio));
		$termino= date('Y/m/d H:i', strtotime($termino));

		$sql = "UPDATE eventos SET  titulo = '$titulo', descripcion = '$descripcion', inicio = '$inicio', termino = '$termino', cor = '$cor' WHERE id_evento = $id_evento ";

		$query = $db->prepare( $sql );
		if ($query == false) {
			print_r($db->errorInfo());
			die ('Error al cargar los turnos');
		}

		$sth = $query->execute();
		if ($sth == false) {
			print_r($query->errorInfo());
			die ('Error al consultar');
		}

	}
	header('Location: ../../index.php');

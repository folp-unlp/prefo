<?php
class Database
{
    private $hostname = 'localhost';
    private $username = 'root';
    private $password = '';
    private $database = 'calendario';
    private $conex;

    public function conectar()
    {
        $this->conex = null;
        try {
            $this->conex = new PDO('mysql:host=' . $this->hostname . ';dbname=' . $this->database . ';charset=utf8', $this->username, $this->password);
        } catch (Exception $e) {
            die('Error : ' . $e->getMessage());
        }

        return $this->conex;
    }
}

<?php
	require_once('conex.php');
	$database = new Database();
	$db = $database->conectar();

	if (isset($_POST['Event'][0]) && isset($_POST['Event'][1]) && isset($_POST['Event'][2])){


		$id_evento = $_POST['Event'][0];
		$inicio = $_POST['Event'][1];
		$termino = $_POST['Event'][2];

		$inicio= date('Y/m/d H:i', strtotime($inicio));
		$termino= date('Y/m/d H:i', strtotime($termino));

		$sql = "UPDATE eventos SET  inicio = '$inicio', termino = '$termino' WHERE id_evento = $id_evento ";


		$query = $db->prepare( $sql );
		if ($query == false) {
			print_r($db->errorInfo());
			die ('Error al cargar los turnos');
		}

		$sth = $query->execute();
		if ($sth == false) {
			print_r($query->errorInfo());
			die ('Error al ejecutar la consulta');
		}else{
			die ('OK');
		}

	}
	//header('Location: '.$_SERVER['HTTP_REFERER']);
?>
